#!/bin/sh

valor0=0
valor1=0
valor2=0
valor3=0
max=0
incremento=1
changed=0
zero=0

#valor0=1000.35
#valor1=0.18
#valor2=0.51
#valor3=50.24


for i in `seq 1 10000`;
do
# change valor 0
echo "incremento:"
echo $incremento
echo "mudei o 0"
valor0=$((valor0 + $incremento))

variableA=$(gtimeout 20s ./lispscript.lisp $valor0 $valor1 $valor2 $valor3)

# echo $variableA
set -- $variableA
if [ "$1" == "" ]; then
echo "time limit reached"
else

if [ $variableA -gt $max ]; then
echo $max
max=$variableA
changed=1
#echo $variableA

fi

fi
# change valor 1
echo "mudei o 1"
valor0=$((valor0 - $incremento))
valor1=$((valor1 + $incremento))

variableA=$(gtimeout 10s ./lispscript.lisp $valor0 $valor1 $valor2 $valor3)

# echo $variableA
set -- $variableA
if [ "$1" == "" ]; then
echo "time limit reached"
else

if [ $variableA -gt $max ]; then
echo $max
max=$variableA
changed=2
echo $variableA

fi

fi



# change valor 2
echo "mudei o 2"
valor1=$((valor1 - $incremento))
valor2=$((valor2 + $incremento))

variableA=$(gtimeout 20s ./lispscript.lisp $valor0 $valor1 $valor2 $valor3)

# echo $variableA
set -- $variableA
if [ "$1" == "" ]; then
echo "time limit reached"
else

if [ $variableA -gt $max ]; then
echo $max
max=$variableA
changed=3
echo $variableA

fi

fi


# change valor 3
echo "mudei o 3"
valor2=$((valor2 - $incremento))
valor3=$((valor3 + $incremento))

variableA=$(gtimeout 20s ./lispscript.lisp $valor0 $valor1 $valor2 $valor3)

# echo $variableA
set -- $variableA
if [ "$1" == "" ]; then
echo "time limit reached"
else

if [ $variableA -gt $max ]; then
echo $max
max=$variableA
changed=4
echo $variableA

fi

fi

echo "changed:"
echo $changed
# correct
valor3=$((valor3 - $incremento))
echo "hello"
if [ $changed -eq 0 ] ; then
incremento=$(($incremento + 1))
fi
echo "passei o primeiro"
if [ $changed -eq 1 ]; then
valor0=$((valor0 + $incremento))
fi

if [ $changed -eq 2 ]; then
valor1=$((valor1 + $incremento))
fi

if [ $changed -eq 3 ]; then
valor2=$((valor2 + $incremento))
fi

if [ $changed -eq 4 ]; then
valor3=$((valor3 + $incremento))
fi

changed=0

echo "how it ended this:"
echo "valor 0:"
echo $valor0
echo "valor 1:"
echo $valor1
echo "valor 2:"
echo $valor2
echo "valor 3:"
echo $valor3
done